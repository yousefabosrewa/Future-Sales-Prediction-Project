word = 'yousef'
lenght = len(word)
i = 0
convert = 0
while i < lenght:
    convert += ord(word[i])
    i+=1

print(convert)
